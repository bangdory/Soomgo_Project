package org.soomgo.soomgo_project.domain.request;

import lombok.Data;

@Data
public class GosuDTO {
    private int num;
    private String id;
    private String region;
    private String type;
}
