package org.soomgo.soomgo_project.domain.category;

import lombok.Data;

@Data
public class CategoryDTO {

    private int categoryNum;
    private int id;
    private int p_Id;
    private String categoryName;

}
