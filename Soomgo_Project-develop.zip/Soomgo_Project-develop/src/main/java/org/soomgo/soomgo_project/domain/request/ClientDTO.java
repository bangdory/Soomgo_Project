package org.soomgo.soomgo_project.domain.request;

import lombok.Data;

@Data
public class ClientDTO {
    private int num;
    private String id;
    private String region;
}
