package org.soomgo.soomgo_project.domain.territory;

import lombok.Data;

@Data
public class TerritoryDTO {

    private int no;
    private int id;
    private String state;
    private String district;

}
