package org.soomgo.soomgo_project.domain.request;

import lombok.Data;

@Data
public class CategoryDTO {
    private int CategoryNum;
    private int Id;
    private int P_Id;
    private String CategoryName;
}
