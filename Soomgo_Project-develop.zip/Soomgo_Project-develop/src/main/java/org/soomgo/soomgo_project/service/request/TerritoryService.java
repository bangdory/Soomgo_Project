package org.soomgo.soomgo_project.service.request;

public class TerritoryService {
}
