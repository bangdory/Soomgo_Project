package org.soomgo.soomgo_project.controller.territory;

public class TerritoryController {
}
